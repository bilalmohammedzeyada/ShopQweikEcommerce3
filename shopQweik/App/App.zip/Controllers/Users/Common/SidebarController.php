<?php

namespace App\Controllers\Users\Common;

use System\Controller;

class SidebarController extends Controller
{
    public function index()
    {
		$data['seller'] = $this->load->model('Loginseller')->user();
        return $this->view->render('users/common/sidebar', $data);
    }
}