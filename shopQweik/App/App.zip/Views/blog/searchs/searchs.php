<div class="content-wrapper">
<div id="hoverOverlay"></div>
<div class="container_12">
<div class="main-container col2-left-layout">

<div class="home-products-box">
<div class="col-sm-12">
	<div class="container">
			<div id="newProducts" class="swiper-container">
				<div class="swiper-wrapper" style="width:2400%;">
				عذراَ لا يوجد نتائج لبحثك 
				</div>
			</div>
		</div>
	</div>
</div>