
<div id="messagesContainer" class="osh-container"></div>
<div class="container -mtxxxl -mbxxl">
	<h1>عربة التسوق</h1>
	<div class="free-shiping-eligible-cart-header"></div>
	<section class="-ptxxxl -plxl -pbxxxl -prxl -align-center">
		<img class="lazy image -mbxl" width="160" height="160" src="<?php echo assets('blog/images/logo/empty-cart.png'); ?>" data-src="<?php echo assets('blog/images/logo/empty-cart.png'); ?>" alt="" >
		<div class="color-default-700 -fs-22 -b -pbxl">عربة التسوق فارغة</div>
		<div class="cms color-default-900 -fs-17 -pbxl">هل لديك حساب؟ سجل دخولك لمشاهدة المنتجات في سلة التسوق الخاصة بك</div>
		<a href="<?php echo url('/'); ?>" class="osh-btn -primary -ptl -pbl -prxxxl -plxxxl -shad -mtxxl"><span class="-fs-14">تسوق</span> </a>
	</section> 
</div>  