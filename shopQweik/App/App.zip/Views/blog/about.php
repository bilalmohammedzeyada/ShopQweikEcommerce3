<div class="about">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-xs-12 col-12">
				<div class="card">
					<div class="card-header">
						اتصل بنا
					</div>
					<div class="card-body">
						<form>
							<div class="form-group">
								<label>اسم المستخدم</label>
								<input type="email" class="form-control" id="" placeholder="اسم المستخدم">
							</div>
							
							<div class="form-group">
								<label>البريد الألكتروني</label>
								<input type="email" class="form-control" placeholder="البريد الألكتروني">
							</div>
							
							<div class="form-group">
								<label for="exampleFormControlTextarea1">الرسالة</label>
								<textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
							</div>
							
							<button type="submit" class="btn btn-primary">ارسل</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
