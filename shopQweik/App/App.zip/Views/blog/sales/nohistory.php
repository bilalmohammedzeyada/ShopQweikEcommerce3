<div class="content-wrapper">
  <div id="hoverOverlay"></div>
    <div class="container_12">
        <div class="main-container col2-left-layout">
			<div class="row clearfix">
				<div class="grid_12"></div>
			</div>
            <div class="clear"></div>
			<div class="row clearfix">
				<div class="grid_9 col-main">
					<div id="algolia-autocomplete-container" class="mangolia"></div><div class="my-account"><div class="page-title">
    <h1>مشترياتي</h1>
</div>
    <p>انت لم تضع اي اوامر.</p>
<div class="buttons-set">
    <p class="back-link"><a href="<?php echo url('/'); ?>"><small>« </small>العودة</a></p>
</div></div>				</div>