<div class="track">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-xs-12 col-12">
				<div class="card">
					<div class="card-header">
						تتبع طلبك
					</div>
					<div class="card-body">
						<form method="POST" action="<?php echo $url; ?>">
							<div class="form-group">
								<label>رقم الطلب</label>
								<input type="text" name="order_number" class="form-control" placeholder="رقم الطلب">
							</div>
							<div class="form-group">
								<label>رقم الهاتف</label>
								<input type="text" name="mobile_number" class="form-control"  placeholder="Password">
							</div>
							<button type="submit" class="btn btn-primary osh-btn">تتبع</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>