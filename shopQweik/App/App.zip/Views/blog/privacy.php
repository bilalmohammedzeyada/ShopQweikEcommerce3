<div class="privacy">
	<div class="container">
		<div class="row">
			<div class="col-sm-12 col-xs-12 col-12">
				<div class="card">
					<div class="card-header">
						سياسة الخصوصية
					</div>
					<div class="card-body">
						هنا سيتم وضع سياسة الخصوصية 
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
