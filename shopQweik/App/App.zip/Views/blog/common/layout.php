<?php echo $header;?>
<?php echo $rightsidebar;?>
<?php echo $content;?>
<?php echo $rightsidebar2;?>
<?php //echo $sidebar;?>
<?php echo $footer;?>