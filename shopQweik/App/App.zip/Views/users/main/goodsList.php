<script type="text/javascript" src="<?php echo assets('users/js/bootstrap.min.js'); ?>"></script>

<div class="panel panel-default">
    <div class="panel-heading">
        <h6 class="panel-title">
            <i class="icon-office"></i>قائمة المنتجات        </h6>
        <a href="<?php echo url('/seller/Goods/index/add'); ?>">
            <button type="button" data-toggle="modal" class="btn btn-default pull-right">
                <i class="icon-star5 pl"></i>اضف منتجك</button>
        </a>
    </div>
<div id="form-results"></div>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
            <tr>
                <td width="40px" height="45" align="center">
                    <div class="checker"><span><input type="checkbox" class="styled" onclick="tableSelectAll(this)"></span></div>
                </td>
                <td width="40px" height="45" align="center"><strong>رقم</strong></td>
                <td width="100px" align="center"><strong>كود المنتج</strong></td>
                <td width="" align="center"><strong>اسم المنتج</strong></td>
                <td width="" align="center"><strong>العلامة التجارية</strong></td>
                <td width="" align="center"><strong>السعر</strong></td>
                <td width="" align="center"><strong>المخزون</strong></td>
                <td width="60px" align="center"><strong>حالة العرض</strong></td>
                <td width="60px" align="center"><strong>حالة التدقيق</strong></td>
                <!--<td width="60px" align="center"><strong>حالة التدقيق</strong></td>-->
                <td width="150px" align="center"><strong>عملية</strong></td>
            </tr>
            </thead>
            <tbody>
			<?php $i =1; 
			if(! empty($posts)) {	
				foreach($posts as $post) { ?>
            <tr>
                    <td align="center">
                     <div class="checker"><span><input type="checkbox" value="2409" class="styled checkboxs" name="selected"></span></div></td>
                    <td align="center"><img src="<?php echo assets('blog/images/posts/' . $post->image); ?>" style="width:50px; height: 50px; border-radius: 100%;" alt="" /><?php echo $post->id; ?></td>
                    <td align="center"><?php echo $post->code; ?></td>
                    <td align="center"><?php echo $post->title; ?></td>
                    <td align="center"><?php echo $post->brands; ?></td>
                    <td align="center"><?php echo $post->price1; ?></td>
                    <td align="center"><?php echo $post->stock; ?></td>
                    <td align="center"><?php 
					if($post->status == 'enabled'){
						echo '<i class="icon-checkmark3"style="color:#3fbd74;cursor:pointer;"></i>';
					} else {
						echo '<i class="icon-checkmark3"></i>';
					}
					?></td>
					<td align="center"><?php 
					if($post->is_accept == 0){
						echo '<i class="icon-checkmark3" style="cursor:pointer;" title="معلقة"> </i>';
					} else if($post->is_accept == 1){
						echo '<i class="icon-checkmark3" style="cursor:pointer;" title="في إنتظار الموافقة"> </i>';
					}else if($post->is_accept == 2){
						echo '<i class="icon-checkmark3" style="color:#3fbd74;cursor:pointer;" title="تمت الموافقة"> </i>';
					}else if($post->is_accept == 3){
						echo '<i class="icon-checkmark3" style="cursor:pointer;" title="مرفوض"> </i>';
					}
					?></td>
                    <td align="left" style="display: inline-flex; margin: 0 3px;">
						<a type="button" class="btn btn-icon btn-info" href="<?php echo url('seller/Goods/index/edit/' . $post->id) ?>"title="تعديل">
                            <i class="icon-pencil3"></i>
                        </a>                        
						<form action="<?php echo url('seller/Goods/index/deactive/' . $post->id) ?>" method="POST" class="form">
							<button type="submit" class="btn btn-danger delete" data-target="" title="حذف">
                            <i class="icon-remove3"></i>
							</button>
						</form>
						
                    </td>
                </tr>
				<?php } } else { ?>
				<tr>
					<td colspan="12" align="center">لم تقم بأضافة أي منتجات</td>
				</tr>
			<?php } ?>           
				</tbody>
        </table>
    </div>
</div>