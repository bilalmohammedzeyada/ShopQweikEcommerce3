<?php echo $header;?>
<?php echo $sidebar;?>
<?php echo $content;?>
<?php echo $footer;?>