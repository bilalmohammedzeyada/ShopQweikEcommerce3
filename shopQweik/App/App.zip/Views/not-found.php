<!DOCTYPE html>

<html>

<head>
  <title>404 Not Found</title>
</head>

<body>

<h1 style="text-align: center">
    Oops! Not Found Page
</h1>

</body>
</html>